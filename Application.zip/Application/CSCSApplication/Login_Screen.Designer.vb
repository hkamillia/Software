﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Login))
        Me.TxtUsername = New System.Windows.Forms.TextBox()
        Me.TxtPassword = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.BtnLogin = New System.Windows.Forms.Button()
        Me.LblNewUser = New System.Windows.Forms.LinkLabel()
        Me.LblForgotPassword = New System.Windows.Forms.LinkLabel()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TxtUsername
        '
        Me.TxtUsername.BackColor = System.Drawing.Color.Ivory
        Me.TxtUsername.Font = New System.Drawing.Font("Agency FB", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtUsername.ForeColor = System.Drawing.Color.Silver
        Me.TxtUsername.Location = New System.Drawing.Point(416, 146)
        Me.TxtUsername.Name = "TxtUsername"
        Me.TxtUsername.Size = New System.Drawing.Size(300, 30)
        Me.TxtUsername.TabIndex = 1
        Me.TxtUsername.TabStop = False
        Me.TxtUsername.Text = "Username"
        '
        'TxtPassword
        '
        Me.TxtPassword.BackColor = System.Drawing.Color.Ivory
        Me.TxtPassword.Font = New System.Drawing.Font("Agency FB", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPassword.ForeColor = System.Drawing.Color.Silver
        Me.TxtPassword.Location = New System.Drawing.Point(416, 191)
        Me.TxtPassword.Name = "TxtPassword"
        Me.TxtPassword.Size = New System.Drawing.Size(300, 30)
        Me.TxtPassword.TabIndex = 2
        Me.TxtPassword.TabStop = False
        Me.TxtPassword.Text = "Password"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label1.Location = New System.Drawing.Point(3, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(375, 28)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Computer Science Course Scheduler"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label2.Location = New System.Drawing.Point(430, 105)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(276, 36)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "ACCOUNT LOGIN"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.SystemColors.Window
        Me.PictureBox2.Image = Global.CSCSApplication.My.Resources.Resources.User
        Me.PictureBox2.Location = New System.Drawing.Point(683, 151)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(23, 21)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.SystemColors.Window
        Me.PictureBox3.Image = Global.CSCSApplication.My.Resources.Resources.lock_grey
        Me.PictureBox3.Location = New System.Drawing.Point(683, 196)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(23, 21)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 8
        Me.PictureBox3.TabStop = False
        '
        'BtnLogin
        '
        Me.BtnLogin.BackColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.BtnLogin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnLogin.Font = New System.Drawing.Font("Agency FB", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLogin.ForeColor = System.Drawing.Color.White
        Me.BtnLogin.Location = New System.Drawing.Point(416, 249)
        Me.BtnLogin.Name = "BtnLogin"
        Me.BtnLogin.Size = New System.Drawing.Size(300, 42)
        Me.BtnLogin.TabIndex = 9
        Me.BtnLogin.TabStop = False
        Me.BtnLogin.Text = "Login"
        Me.BtnLogin.UseVisualStyleBackColor = False
        '
        'LblNewUser
        '
        Me.LblNewUser.ActiveLinkColor = System.Drawing.Color.Silver
        Me.LblNewUser.AutoSize = True
        Me.LblNewUser.BackColor = System.Drawing.Color.Transparent
        Me.LblNewUser.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblNewUser.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblNewUser.Font = New System.Drawing.Font("Agency FB", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNewUser.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblNewUser.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblNewUser.LinkColor = System.Drawing.Color.ForestGreen
        Me.LblNewUser.Location = New System.Drawing.Point(530, 294)
        Me.LblNewUser.Name = "LblNewUser"
        Me.LblNewUser.Size = New System.Drawing.Size(77, 26)
        Me.LblNewUser.TabIndex = 10
        Me.LblNewUser.TabStop = True
        Me.LblNewUser.Text = "New User?"
        '
        'LblForgotPassword
        '
        Me.LblForgotPassword.ActiveLinkColor = System.Drawing.Color.Gold
        Me.LblForgotPassword.AutoSize = True
        Me.LblForgotPassword.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblForgotPassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblForgotPassword.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblForgotPassword.Font = New System.Drawing.Font("Agency FB", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblForgotPassword.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblForgotPassword.LinkColor = System.Drawing.Color.ForestGreen
        Me.LblForgotPassword.Location = New System.Drawing.Point(496, 338)
        Me.LblForgotPassword.Name = "LblForgotPassword"
        Me.LblForgotPassword.Size = New System.Drawing.Size(149, 26)
        Me.LblForgotPassword.TabIndex = 11
        Me.LblForgotPassword.TabStop = True
        Me.LblForgotPassword.Text = "Forgot your password?"
        '
        'Login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(777, 484)
        Me.Controls.Add(Me.LblForgotPassword)
        Me.Controls.Add(Me.LblNewUser)
        Me.Controls.Add(Me.BtnLogin)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtPassword)
        Me.Controls.Add(Me.TxtUsername)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Monotype Corsiva", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Login"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtUsername As TextBox
    Friend WithEvents TxtPassword As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents BtnLogin As Button
    Friend WithEvents LblNewUser As LinkLabel
    Friend WithEvents LblForgotPassword As LinkLabel
End Class

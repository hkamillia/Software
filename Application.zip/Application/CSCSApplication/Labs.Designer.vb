﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Labs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Labs))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LblCSCS = New System.Windows.Forms.Label()
        Me.LblLogout = New System.Windows.Forms.LinkLabel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LblViewTimetable = New System.Windows.Forms.Label()
        Me.LblHome = New System.Windows.Forms.LinkLabel()
        Me.TabLabs = New System.Windows.Forms.TabControl()
        Me.AddLab = New System.Windows.Forms.TabPage()
        Me.LblAllLabs = New System.Windows.Forms.Label()
        Me.DgdLabs = New System.Windows.Forms.DataGridView()
        Me.LblSeating = New System.Windows.Forms.Label()
        Me.LblName = New System.Windows.Forms.Label()
        Me.LblLabID = New System.Windows.Forms.Label()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.TxtSeating = New System.Windows.Forms.TextBox()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.TxtLabID = New System.Windows.Forms.TextBox()
        Me.UpdateLab = New System.Windows.Forms.TabPage()
        Me.LblAllLecturers2 = New System.Windows.Forms.Label()
        Me.BtnSearch = New System.Windows.Forms.Button()
        Me.TxtSeating2 = New System.Windows.Forms.TextBox()
        Me.LblSeating2 = New System.Windows.Forms.Label()
        Me.TxtName2 = New System.Windows.Forms.TextBox()
        Me.LblName2 = New System.Windows.Forms.Label()
        Me.BtnUpdate = New System.Windows.Forms.Button()
        Me.TxtLabID2 = New System.Windows.Forms.TextBox()
        Me.LblLabID2 = New System.Windows.Forms.Label()
        Me.DgdLabs2 = New System.Windows.Forms.DataGridView()
        Me.ViewLabs = New System.Windows.Forms.TabPage()
        Me.LblLabs3 = New System.Windows.Forms.Label()
        Me.DgdLabs3 = New System.Windows.Forms.DataGridView()
        Me.DeleteLab = New System.Windows.Forms.TabPage()
        Me.LablLabs4 = New System.Windows.Forms.Label()
        Me.BtnDelete = New System.Windows.Forms.Button()
        Me.LblDelete = New System.Windows.Forms.Label()
        Me.DgdLabs4 = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabLabs.SuspendLayout()
        Me.AddLab.SuspendLayout()
        CType(Me.DgdLabs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UpdateLab.SuspendLayout()
        CType(Me.DgdLabs2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ViewLabs.SuspendLayout()
        CType(Me.DgdLabs3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DeleteLab.SuspendLayout()
        CType(Me.DgdLabs4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.Controls.Add(Me.LblCSCS)
        Me.Panel1.Controls.Add(Me.LblLogout)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(777, 49)
        Me.Panel1.TabIndex = 3
        '
        'LblCSCS
        '
        Me.LblCSCS.AutoSize = True
        Me.LblCSCS.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCSCS.ForeColor = System.Drawing.Color.Ivory
        Me.LblCSCS.Image = CType(resources.GetObject("LblCSCS.Image"), System.Drawing.Image)
        Me.LblCSCS.Location = New System.Drawing.Point(186, 9)
        Me.LblCSCS.Name = "LblCSCS"
        Me.LblCSCS.Size = New System.Drawing.Size(440, 31)
        Me.LblCSCS.TabIndex = 34
        Me.LblCSCS.Text = "Computer Science Course Scheduler"
        '
        'LblLogout
        '
        Me.LblLogout.ActiveLinkColor = System.Drawing.Color.OliveDrab
        Me.LblLogout.AutoSize = True
        Me.LblLogout.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblLogout.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogout.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblLogout.LinkColor = System.Drawing.Color.DarkGreen
        Me.LblLogout.Location = New System.Drawing.Point(683, 18)
        Me.LblLogout.Name = "LblLogout"
        Me.LblLogout.Size = New System.Drawing.Size(79, 20)
        Me.LblLogout.TabIndex = 9
        Me.LblLogout.TabStop = True
        Me.LblLogout.Text = "LOGOUT"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.LblViewTimetable)
        Me.Panel2.Controls.Add(Me.LblHome)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 49)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(777, 37)
        Me.Panel2.TabIndex = 5
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.PictureBox2.Image = Global.CSCSApplication.My.Resources.Resources.light_usc_logo
        Me.PictureBox2.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(67, 37)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 35
        Me.PictureBox2.TabStop = False
        '
        'LblViewTimetable
        '
        Me.LblViewTimetable.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblViewTimetable.AutoSize = True
        Me.LblViewTimetable.BackColor = System.Drawing.Color.Transparent
        Me.LblViewTimetable.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblViewTimetable.ForeColor = System.Drawing.Color.Black
        Me.LblViewTimetable.Location = New System.Drawing.Point(312, 8)
        Me.LblViewTimetable.Name = "LblViewTimetable"
        Me.LblViewTimetable.Size = New System.Drawing.Size(135, 24)
        Me.LblViewTimetable.TabIndex = 34
        Me.LblViewTimetable.Text = "Manage Labs"
        Me.LblViewTimetable.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LblHome
        '
        Me.LblHome.AutoSize = True
        Me.LblHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblHome.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHome.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblHome.LinkColor = System.Drawing.Color.DarkGreen
        Me.LblHome.Location = New System.Drawing.Point(634, 12)
        Me.LblHome.Name = "LblHome"
        Me.LblHome.Size = New System.Drawing.Size(139, 18)
        Me.LblHome.TabIndex = 33
        Me.LblHome.TabStop = True
        Me.LblHome.Text = "<<Return to Home"
        '
        'TabLabs
        '
        Me.TabLabs.Controls.Add(Me.AddLab)
        Me.TabLabs.Controls.Add(Me.UpdateLab)
        Me.TabLabs.Controls.Add(Me.ViewLabs)
        Me.TabLabs.Controls.Add(Me.DeleteLab)
        Me.TabLabs.Location = New System.Drawing.Point(3, 92)
        Me.TabLabs.Name = "TabLabs"
        Me.TabLabs.SelectedIndex = 0
        Me.TabLabs.Size = New System.Drawing.Size(774, 395)
        Me.TabLabs.TabIndex = 6
        '
        'AddLab
        '
        Me.AddLab.BackgroundImage = CType(resources.GetObject("AddLab.BackgroundImage"), System.Drawing.Image)
        Me.AddLab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.AddLab.Controls.Add(Me.LblAllLabs)
        Me.AddLab.Controls.Add(Me.DgdLabs)
        Me.AddLab.Controls.Add(Me.LblSeating)
        Me.AddLab.Controls.Add(Me.LblName)
        Me.AddLab.Controls.Add(Me.LblLabID)
        Me.AddLab.Controls.Add(Me.BtnAdd)
        Me.AddLab.Controls.Add(Me.TxtSeating)
        Me.AddLab.Controls.Add(Me.TxtName)
        Me.AddLab.Controls.Add(Me.TxtLabID)
        Me.AddLab.Location = New System.Drawing.Point(4, 22)
        Me.AddLab.Name = "AddLab"
        Me.AddLab.Padding = New System.Windows.Forms.Padding(3)
        Me.AddLab.Size = New System.Drawing.Size(766, 369)
        Me.AddLab.TabIndex = 0
        Me.AddLab.Text = "Add Lab"
        Me.AddLab.UseVisualStyleBackColor = True
        '
        'LblAllLabs
        '
        Me.LblAllLabs.AutoSize = True
        Me.LblAllLabs.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblAllLabs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblAllLabs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAllLabs.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblAllLabs.Location = New System.Drawing.Point(520, 13)
        Me.LblAllLabs.Name = "LblAllLabs"
        Me.LblAllLabs.Size = New System.Drawing.Size(58, 18)
        Me.LblAllLabs.TabIndex = 11
        Me.LblAllLabs.Text = "All Labs"
        '
        'DgdLabs
        '
        Me.DgdLabs.AllowUserToAddRows = False
        Me.DgdLabs.AllowUserToDeleteRows = False
        Me.DgdLabs.AllowUserToOrderColumns = True
        Me.DgdLabs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgdLabs.GridColor = System.Drawing.Color.Honeydew
        Me.DgdLabs.Location = New System.Drawing.Point(322, 34)
        Me.DgdLabs.Name = "DgdLabs"
        Me.DgdLabs.ReadOnly = True
        Me.DgdLabs.Size = New System.Drawing.Size(438, 327)
        Me.DgdLabs.TabIndex = 10
        '
        'LblSeating
        '
        Me.LblSeating.AutoSize = True
        Me.LblSeating.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblSeating.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblSeating.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSeating.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblSeating.Location = New System.Drawing.Point(13, 148)
        Me.LblSeating.Name = "LblSeating"
        Me.LblSeating.Size = New System.Drawing.Size(115, 18)
        Me.LblSeating.TabIndex = 8
        Me.LblSeating.Text = "Seating Capacity:"
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblName.Location = New System.Drawing.Point(26, 97)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(100, 18)
        Me.LblName.TabIndex = 7
        Me.LblName.Text = "Lab Full Name:"
        '
        'LblLabID
        '
        Me.LblLabID.AutoSize = True
        Me.LblLabID.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblLabID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLabID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLabID.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblLabID.Location = New System.Drawing.Point(15, 49)
        Me.LblLabID.Name = "LblLabID"
        Me.LblLabID.Size = New System.Drawing.Size(109, 18)
        Me.LblLabID.TabIndex = 6
        Me.LblLabID.Text = "Lab ID/Acronym:"
        '
        'BtnAdd
        '
        Me.BtnAdd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAdd.ForeColor = System.Drawing.Color.Black
        Me.BtnAdd.Location = New System.Drawing.Point(134, 200)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(93, 23)
        Me.BtnAdd.TabIndex = 5
        Me.BtnAdd.Text = "Add"
        Me.BtnAdd.UseVisualStyleBackColor = True
        '
        'TxtSeating
        '
        Me.TxtSeating.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtSeating.Location = New System.Drawing.Point(137, 146)
        Me.TxtSeating.Name = "TxtSeating"
        Me.TxtSeating.Size = New System.Drawing.Size(90, 20)
        Me.TxtSeating.TabIndex = 2
        '
        'TxtName
        '
        Me.TxtName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtName.Location = New System.Drawing.Point(137, 96)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(146, 20)
        Me.TxtName.TabIndex = 1
        '
        'TxtLabID
        '
        Me.TxtLabID.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtLabID.Location = New System.Drawing.Point(138, 47)
        Me.TxtLabID.Name = "TxtLabID"
        Me.TxtLabID.Size = New System.Drawing.Size(121, 20)
        Me.TxtLabID.TabIndex = 0
        '
        'UpdateLab
        '
        Me.UpdateLab.BackgroundImage = CType(resources.GetObject("UpdateLab.BackgroundImage"), System.Drawing.Image)
        Me.UpdateLab.Controls.Add(Me.LblAllLecturers2)
        Me.UpdateLab.Controls.Add(Me.BtnSearch)
        Me.UpdateLab.Controls.Add(Me.TxtSeating2)
        Me.UpdateLab.Controls.Add(Me.LblSeating2)
        Me.UpdateLab.Controls.Add(Me.TxtName2)
        Me.UpdateLab.Controls.Add(Me.LblName2)
        Me.UpdateLab.Controls.Add(Me.BtnUpdate)
        Me.UpdateLab.Controls.Add(Me.TxtLabID2)
        Me.UpdateLab.Controls.Add(Me.LblLabID2)
        Me.UpdateLab.Controls.Add(Me.DgdLabs2)
        Me.UpdateLab.Location = New System.Drawing.Point(4, 22)
        Me.UpdateLab.Name = "UpdateLab"
        Me.UpdateLab.Padding = New System.Windows.Forms.Padding(3)
        Me.UpdateLab.Size = New System.Drawing.Size(766, 369)
        Me.UpdateLab.TabIndex = 1
        Me.UpdateLab.Text = "Update Lab"
        Me.UpdateLab.UseVisualStyleBackColor = True
        '
        'LblAllLecturers2
        '
        Me.LblAllLecturers2.AutoSize = True
        Me.LblAllLecturers2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblAllLecturers2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblAllLecturers2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAllLecturers2.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblAllLecturers2.Location = New System.Drawing.Point(511, 13)
        Me.LblAllLecturers2.Name = "LblAllLecturers2"
        Me.LblAllLecturers2.Size = New System.Drawing.Size(58, 18)
        Me.LblAllLecturers2.TabIndex = 24
        Me.LblAllLecturers2.Text = "All Labs"
        '
        'BtnSearch
        '
        Me.BtnSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSearch.Location = New System.Drawing.Point(232, 45)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.Size = New System.Drawing.Size(75, 23)
        Me.BtnSearch.TabIndex = 14
        Me.BtnSearch.Text = "Search"
        Me.BtnSearch.UseVisualStyleBackColor = True
        '
        'TxtSeating2
        '
        Me.TxtSeating2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtSeating2.Location = New System.Drawing.Point(149, 140)
        Me.TxtSeating2.Name = "TxtSeating2"
        Me.TxtSeating2.Size = New System.Drawing.Size(77, 20)
        Me.TxtSeating2.TabIndex = 18
        '
        'LblSeating2
        '
        Me.LblSeating2.AutoSize = True
        Me.LblSeating2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblSeating2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblSeating2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSeating2.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblSeating2.Location = New System.Drawing.Point(19, 141)
        Me.LblSeating2.Name = "LblSeating2"
        Me.LblSeating2.Size = New System.Drawing.Size(115, 18)
        Me.LblSeating2.TabIndex = 17
        Me.LblSeating2.Text = "Seating Capacity:"
        '
        'TxtName2
        '
        Me.TxtName2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtName2.Location = New System.Drawing.Point(149, 95)
        Me.TxtName2.Name = "TxtName2"
        Me.TxtName2.Size = New System.Drawing.Size(158, 20)
        Me.TxtName2.TabIndex = 16
        '
        'LblName2
        '
        Me.LblName2.AutoSize = True
        Me.LblName2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblName2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblName2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName2.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblName2.Location = New System.Drawing.Point(19, 96)
        Me.LblName2.Name = "LblName2"
        Me.LblName2.Size = New System.Drawing.Size(100, 18)
        Me.LblName2.TabIndex = 15
        Me.LblName2.Text = "Lab Full Name:"
        '
        'BtnUpdate
        '
        Me.BtnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnUpdate.Location = New System.Drawing.Point(149, 196)
        Me.BtnUpdate.Name = "BtnUpdate"
        Me.BtnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.BtnUpdate.TabIndex = 23
        Me.BtnUpdate.Text = "Update"
        Me.BtnUpdate.UseVisualStyleBackColor = True
        '
        'TxtLabID2
        '
        Me.TxtLabID2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtLabID2.Location = New System.Drawing.Point(149, 47)
        Me.TxtLabID2.Name = "TxtLabID2"
        Me.TxtLabID2.Size = New System.Drawing.Size(77, 20)
        Me.TxtLabID2.TabIndex = 13
        '
        'LblLabID2
        '
        Me.LblLabID2.AutoSize = True
        Me.LblLabID2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblLabID2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLabID2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLabID2.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblLabID2.Location = New System.Drawing.Point(19, 47)
        Me.LblLabID2.Name = "LblLabID2"
        Me.LblLabID2.Size = New System.Drawing.Size(109, 18)
        Me.LblLabID2.TabIndex = 12
        Me.LblLabID2.Text = "Lab ID/Acronym:"
        '
        'DgdLabs2
        '
        Me.DgdLabs2.AllowUserToAddRows = False
        Me.DgdLabs2.AllowUserToDeleteRows = False
        Me.DgdLabs2.AllowUserToOrderColumns = True
        Me.DgdLabs2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgdLabs2.Location = New System.Drawing.Point(322, 34)
        Me.DgdLabs2.Name = "DgdLabs2"
        Me.DgdLabs2.ReadOnly = True
        Me.DgdLabs2.Size = New System.Drawing.Size(438, 327)
        Me.DgdLabs2.TabIndex = 11
        '
        'ViewLabs
        '
        Me.ViewLabs.BackgroundImage = CType(resources.GetObject("ViewLabs.BackgroundImage"), System.Drawing.Image)
        Me.ViewLabs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ViewLabs.Controls.Add(Me.LblLabs3)
        Me.ViewLabs.Controls.Add(Me.DgdLabs3)
        Me.ViewLabs.Location = New System.Drawing.Point(4, 22)
        Me.ViewLabs.Name = "ViewLabs"
        Me.ViewLabs.Padding = New System.Windows.Forms.Padding(3)
        Me.ViewLabs.Size = New System.Drawing.Size(766, 369)
        Me.ViewLabs.TabIndex = 2
        Me.ViewLabs.Text = "View Labs"
        Me.ViewLabs.UseVisualStyleBackColor = True
        '
        'LblLabs3
        '
        Me.LblLabs3.AutoSize = True
        Me.LblLabs3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblLabs3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLabs3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLabs3.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblLabs3.Location = New System.Drawing.Point(356, 10)
        Me.LblLabs3.Name = "LblLabs3"
        Me.LblLabs3.Size = New System.Drawing.Size(58, 18)
        Me.LblLabs3.TabIndex = 25
        Me.LblLabs3.Text = "All Labs"
        '
        'DgdLabs3
        '
        Me.DgdLabs3.AllowUserToAddRows = False
        Me.DgdLabs3.AllowUserToDeleteRows = False
        Me.DgdLabs3.AllowUserToOrderColumns = True
        Me.DgdLabs3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgdLabs3.GridColor = System.Drawing.Color.Honeydew
        Me.DgdLabs3.Location = New System.Drawing.Point(18, 31)
        Me.DgdLabs3.Name = "DgdLabs3"
        Me.DgdLabs3.ReadOnly = True
        Me.DgdLabs3.Size = New System.Drawing.Size(731, 296)
        Me.DgdLabs3.TabIndex = 0
        '
        'DeleteLab
        '
        Me.DeleteLab.BackgroundImage = CType(resources.GetObject("DeleteLab.BackgroundImage"), System.Drawing.Image)
        Me.DeleteLab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DeleteLab.Controls.Add(Me.LablLabs4)
        Me.DeleteLab.Controls.Add(Me.BtnDelete)
        Me.DeleteLab.Controls.Add(Me.LblDelete)
        Me.DeleteLab.Controls.Add(Me.DgdLabs4)
        Me.DeleteLab.Location = New System.Drawing.Point(4, 22)
        Me.DeleteLab.Name = "DeleteLab"
        Me.DeleteLab.Padding = New System.Windows.Forms.Padding(3)
        Me.DeleteLab.Size = New System.Drawing.Size(766, 369)
        Me.DeleteLab.TabIndex = 3
        Me.DeleteLab.Text = "Delete Lab"
        Me.DeleteLab.UseVisualStyleBackColor = True
        '
        'LablLabs4
        '
        Me.LablLabs4.AutoSize = True
        Me.LablLabs4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LablLabs4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LablLabs4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LablLabs4.ForeColor = System.Drawing.Color.DarkGreen
        Me.LablLabs4.Location = New System.Drawing.Point(441, 3)
        Me.LablLabs4.Name = "LablLabs4"
        Me.LablLabs4.Size = New System.Drawing.Size(58, 18)
        Me.LablLabs4.TabIndex = 26
        Me.LablLabs4.Text = "All Labs"
        '
        'BtnDelete
        '
        Me.BtnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDelete.Location = New System.Drawing.Point(56, 325)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(75, 23)
        Me.BtnDelete.TabIndex = 25
        Me.BtnDelete.Text = "Delete "
        Me.BtnDelete.UseVisualStyleBackColor = True
        '
        'LblDelete
        '
        Me.LblDelete.AutoSize = True
        Me.LblDelete.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblDelete.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDelete.ForeColor = System.Drawing.Color.Black
        Me.LblDelete.Location = New System.Drawing.Point(9, 24)
        Me.LblDelete.Name = "LblDelete"
        Me.LblDelete.Size = New System.Drawing.Size(180, 18)
        Me.LblDelete.TabIndex = 24
        Me.LblDelete.Text = "Select Row then click delete:"
        '
        'DgdLabs4
        '
        Me.DgdLabs4.AllowUserToAddRows = False
        Me.DgdLabs4.AllowUserToDeleteRows = False
        Me.DgdLabs4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgdLabs4.GridColor = System.Drawing.Color.Honeydew
        Me.DgdLabs4.Location = New System.Drawing.Point(195, 24)
        Me.DgdLabs4.Name = "DgdLabs4"
        Me.DgdLabs4.ReadOnly = True
        Me.DgdLabs4.Size = New System.Drawing.Size(555, 324)
        Me.DgdLabs4.TabIndex = 0
        '
        'Labs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(777, 484)
        Me.Controls.Add(Me.TabLabs)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Labs"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Labs"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabLabs.ResumeLayout(False)
        Me.AddLab.ResumeLayout(False)
        Me.AddLab.PerformLayout()
        CType(Me.DgdLabs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UpdateLab.ResumeLayout(False)
        Me.UpdateLab.PerformLayout()
        CType(Me.DgdLabs2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ViewLabs.ResumeLayout(False)
        Me.ViewLabs.PerformLayout()
        CType(Me.DgdLabs3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DeleteLab.ResumeLayout(False)
        Me.DeleteLab.PerformLayout()
        CType(Me.DgdLabs4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TabLabs As TabControl
    Friend WithEvents AddLab As TabPage
    Friend WithEvents LblAllLabs As Label
    Friend WithEvents DgdLabs As DataGridView
    Friend WithEvents LblSeating As Label
    Friend WithEvents LblName As Label
    Friend WithEvents LblLabID As Label
    Friend WithEvents BtnAdd As Button
    Friend WithEvents TxtSeating As TextBox
    Friend WithEvents TxtName As TextBox
    Friend WithEvents TxtLabID As TextBox
    Friend WithEvents UpdateLab As TabPage
    Friend WithEvents LblAllLecturers2 As Label
    Friend WithEvents BtnSearch As Button
    Friend WithEvents TxtSeating2 As TextBox
    Friend WithEvents LblSeating2 As Label
    Friend WithEvents TxtName2 As TextBox
    Friend WithEvents LblName2 As Label
    Friend WithEvents BtnUpdate As Button
    Friend WithEvents TxtLabID2 As TextBox
    Friend WithEvents LblLabID2 As Label
    Friend WithEvents DgdLabs2 As DataGridView
    Friend WithEvents ViewLabs As TabPage
    Friend WithEvents LblLabs3 As Label
    Friend WithEvents DgdLabs3 As DataGridView
    Friend WithEvents DeleteLab As TabPage
    Friend WithEvents BtnDelete As Button
    Friend WithEvents LblDelete As Label
    Friend WithEvents DgdLabs4 As DataGridView
    Friend WithEvents LablLabs4 As Label
    Friend WithEvents LblLogout As LinkLabel
    Friend WithEvents LblHome As LinkLabel
    Friend WithEvents LblViewTimetable As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents LblCSCS As Label
End Class

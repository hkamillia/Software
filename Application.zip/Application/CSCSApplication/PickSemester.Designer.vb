﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PickSemCreate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PickSemCreate))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LblLogout = New System.Windows.Forms.LinkLabel()
        Me.LsbCourses = New System.Windows.Forms.ListBox()
        Me.TxtCrsCode = New System.Windows.Forms.TextBox()
        Me.TxtCrsTitle = New System.Windows.Forms.TextBox()
        Me.LblCrsCode = New System.Windows.Forms.Label()
        Me.LblCrsTitle = New System.Windows.Forms.Label()
        Me.LblCrsType = New System.Windows.Forms.Label()
        Me.CmbType = New System.Windows.Forms.ComboBox()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.BtnDelete = New System.Windows.Forms.Button()
        Me.LblDelete = New System.Windows.Forms.Label()
        Me.LblNext = New System.Windows.Forms.LinkLabel()
        Me.LblHome = New System.Windows.Forms.LinkLabel()
        Me.LblCredits = New System.Windows.Forms.Label()
        Me.TxtCredits = New System.Windows.Forms.TextBox()
        Me.TxtClassSize = New System.Windows.Forms.TextBox()
        Me.LblClassSize = New System.Windows.Forms.Label()
        Me.BtnSemester3 = New System.Windows.Forms.RadioButton()
        Me.BtnSemester2 = New System.Windows.Forms.RadioButton()
        Me.BtnSemester1 = New System.Windows.Forms.RadioButton()
        Me.LblInstructions = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LblViewTimetable = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.LblLogout)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(777, 49)
        Me.Panel1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Ivory
        Me.Label1.Image = CType(resources.GetObject("Label1.Image"), System.Drawing.Image)
        Me.Label1.Location = New System.Drawing.Point(182, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(431, 33)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Computer Science Course Scheduler"
        '
        'LblLogout
        '
        Me.LblLogout.ActiveLinkColor = System.Drawing.Color.OliveDrab
        Me.LblLogout.AutoSize = True
        Me.LblLogout.BackColor = System.Drawing.Color.Transparent
        Me.LblLogout.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogout.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblLogout.LinkColor = System.Drawing.Color.DarkGreen
        Me.LblLogout.Location = New System.Drawing.Point(667, 14)
        Me.LblLogout.Name = "LblLogout"
        Me.LblLogout.Size = New System.Drawing.Size(84, 22)
        Me.LblLogout.TabIndex = 9
        Me.LblLogout.TabStop = True
        Me.LblLogout.Text = "LOGOUT"
        '
        'LsbCourses
        '
        Me.LsbCourses.FormattingEnabled = True
        Me.LsbCourses.Location = New System.Drawing.Point(182, 118)
        Me.LsbCourses.Name = "LsbCourses"
        Me.LsbCourses.Size = New System.Drawing.Size(321, 290)
        Me.LsbCourses.TabIndex = 11
        '
        'TxtCrsCode
        '
        Me.TxtCrsCode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCrsCode.Location = New System.Drawing.Point(509, 142)
        Me.TxtCrsCode.Name = "TxtCrsCode"
        Me.TxtCrsCode.Size = New System.Drawing.Size(152, 20)
        Me.TxtCrsCode.TabIndex = 12
        '
        'TxtCrsTitle
        '
        Me.TxtCrsTitle.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCrsTitle.Location = New System.Drawing.Point(510, 189)
        Me.TxtCrsTitle.Name = "TxtCrsTitle"
        Me.TxtCrsTitle.Size = New System.Drawing.Size(152, 20)
        Me.TxtCrsTitle.TabIndex = 13
        '
        'LblCrsCode
        '
        Me.LblCrsCode.AutoSize = True
        Me.LblCrsCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblCrsCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCrsCode.Location = New System.Drawing.Point(511, 121)
        Me.LblCrsCode.Name = "LblCrsCode"
        Me.LblCrsCode.Size = New System.Drawing.Size(120, 18)
        Me.LblCrsCode.TabIndex = 15
        Me.LblCrsCode.Text = "Course Code-Sec:"
        '
        'LblCrsTitle
        '
        Me.LblCrsTitle.AutoSize = True
        Me.LblCrsTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblCrsTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCrsTitle.Location = New System.Drawing.Point(511, 169)
        Me.LblCrsTitle.Name = "LblCrsTitle"
        Me.LblCrsTitle.Size = New System.Drawing.Size(85, 18)
        Me.LblCrsTitle.TabIndex = 16
        Me.LblCrsTitle.Text = "Course Title:"
        '
        'LblCrsType
        '
        Me.LblCrsType.AutoSize = True
        Me.LblCrsType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblCrsType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCrsType.Location = New System.Drawing.Point(511, 262)
        Me.LblCrsType.Name = "LblCrsType"
        Me.LblCrsType.Size = New System.Drawing.Size(91, 18)
        Me.LblCrsType.TabIndex = 17
        Me.LblCrsType.Text = "Course Type:"
        '
        'CmbType
        '
        Me.CmbType.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbType.FormattingEnabled = True
        Me.CmbType.Items.AddRange(New Object() {"Core", "Cognate", "Emphasis", "Elective", "General Ed"})
        Me.CmbType.Location = New System.Drawing.Point(510, 283)
        Me.CmbType.Name = "CmbType"
        Me.CmbType.Size = New System.Drawing.Size(152, 21)
        Me.CmbType.TabIndex = 18
        '
        'BtnAdd
        '
        Me.BtnAdd.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnAdd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAdd.Location = New System.Drawing.Point(669, 329)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(75, 23)
        Me.BtnAdd.TabIndex = 20
        Me.BtnAdd.Text = "Add"
        Me.BtnAdd.UseVisualStyleBackColor = False
        '
        'BtnDelete
        '
        Me.BtnDelete.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnDelete.Location = New System.Drawing.Point(511, 385)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(75, 23)
        Me.BtnDelete.TabIndex = 21
        Me.BtnDelete.Text = "Delete "
        Me.BtnDelete.UseVisualStyleBackColor = False
        '
        'LblDelete
        '
        Me.LblDelete.AutoSize = True
        Me.LblDelete.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDelete.Location = New System.Drawing.Point(513, 362)
        Me.LblDelete.Name = "LblDelete"
        Me.LblDelete.Size = New System.Drawing.Size(196, 18)
        Me.LblDelete.TabIndex = 23
        Me.LblDelete.Text = "Select Course then click delete:"
        '
        'LblNext
        '
        Me.LblNext.AutoSize = True
        Me.LblNext.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblNext.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNext.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblNext.LinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LblNext.Location = New System.Drawing.Point(668, 445)
        Me.LblNext.Name = "LblNext"
        Me.LblNext.Size = New System.Drawing.Size(61, 22)
        Me.LblNext.TabIndex = 24
        Me.LblNext.TabStop = True
        Me.LblNext.Text = "Next>>"
        '
        'LblHome
        '
        Me.LblHome.AutoSize = True
        Me.LblHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHome.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblHome.LinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LblHome.Location = New System.Drawing.Point(624, 10)
        Me.LblHome.Name = "LblHome"
        Me.LblHome.Size = New System.Drawing.Size(141, 20)
        Me.LblHome.TabIndex = 2
        Me.LblHome.TabStop = True
        Me.LblHome.Text = "<<Return to Home"
        '
        'LblCredits
        '
        Me.LblCredits.AutoSize = True
        Me.LblCredits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblCredits.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCredits.Location = New System.Drawing.Point(511, 215)
        Me.LblCredits.Name = "LblCredits"
        Me.LblCredits.Size = New System.Drawing.Size(55, 18)
        Me.LblCredits.TabIndex = 25
        Me.LblCredits.Text = "Credits:"
        '
        'TxtCredits
        '
        Me.TxtCredits.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCredits.Location = New System.Drawing.Point(510, 235)
        Me.TxtCredits.Name = "TxtCredits"
        Me.TxtCredits.Size = New System.Drawing.Size(152, 20)
        Me.TxtCredits.TabIndex = 14
        '
        'TxtClassSize
        '
        Me.TxtClassSize.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtClassSize.Location = New System.Drawing.Point(511, 331)
        Me.TxtClassSize.Name = "TxtClassSize"
        Me.TxtClassSize.Size = New System.Drawing.Size(152, 20)
        Me.TxtClassSize.TabIndex = 19
        '
        'LblClassSize
        '
        Me.LblClassSize.AutoSize = True
        Me.LblClassSize.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblClassSize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblClassSize.Location = New System.Drawing.Point(511, 309)
        Me.LblClassSize.Name = "LblClassSize"
        Me.LblClassSize.Size = New System.Drawing.Size(136, 18)
        Me.LblClassSize.TabIndex = 28
        Me.LblClassSize.Text = "Maximum Class Size:"
        '
        'BtnSemester3
        '
        Me.BtnSemester3.AutoSize = True
        Me.BtnSemester3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnSemester3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSemester3.Font = New System.Drawing.Font("MS Reference Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSemester3.Location = New System.Drawing.Point(44, 208)
        Me.BtnSemester3.Name = "BtnSemester3"
        Me.BtnSemester3.Size = New System.Drawing.Size(114, 20)
        Me.BtnSemester3.TabIndex = 4
        Me.BtnSemester3.Text = "3rd Semester"
        Me.BtnSemester3.UseVisualStyleBackColor = False
        '
        'BtnSemester2
        '
        Me.BtnSemester2.AutoSize = True
        Me.BtnSemester2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnSemester2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSemester2.Font = New System.Drawing.Font("MS Reference Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSemester2.Location = New System.Drawing.Point(44, 178)
        Me.BtnSemester2.Name = "BtnSemester2"
        Me.BtnSemester2.Size = New System.Drawing.Size(117, 20)
        Me.BtnSemester2.TabIndex = 3
        Me.BtnSemester2.Text = "2nd Semester"
        Me.BtnSemester2.UseVisualStyleBackColor = False
        '
        'BtnSemester1
        '
        Me.BtnSemester1.AutoSize = True
        Me.BtnSemester1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnSemester1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSemester1.Font = New System.Drawing.Font("MS Reference Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSemester1.Location = New System.Drawing.Point(44, 146)
        Me.BtnSemester1.Name = "BtnSemester1"
        Me.BtnSemester1.Size = New System.Drawing.Size(114, 20)
        Me.BtnSemester1.TabIndex = 2
        Me.BtnSemester1.Text = "1st Semester"
        Me.BtnSemester1.UseVisualStyleBackColor = False
        '
        'LblInstructions
        '
        Me.LblInstructions.AutoSize = True
        Me.LblInstructions.BackColor = System.Drawing.Color.Transparent
        Me.LblInstructions.Font = New System.Drawing.Font("MS Reference Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblInstructions.Location = New System.Drawing.Point(38, 118)
        Me.LblInstructions.Name = "LblInstructions"
        Me.LblInstructions.Size = New System.Drawing.Size(136, 16)
        Me.LblInstructions.TabIndex = 5
        Me.LblInstructions.Text = "Select a Semester:"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.LightGray
        Me.PictureBox2.Image = Global.CSCSApplication.My.Resources.Resources.light_usc_logo
        Me.PictureBox2.Location = New System.Drawing.Point(2, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(57, 44)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'LblViewTimetable
        '
        Me.LblViewTimetable.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblViewTimetable.AutoSize = True
        Me.LblViewTimetable.BackColor = System.Drawing.Color.Transparent
        Me.LblViewTimetable.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblViewTimetable.ForeColor = System.Drawing.Color.Black
        Me.LblViewTimetable.Location = New System.Drawing.Point(303, 10)
        Me.LblViewTimetable.Name = "LblViewTimetable"
        Me.LblViewTimetable.Size = New System.Drawing.Size(160, 24)
        Me.LblViewTimetable.TabIndex = 0
        Me.LblViewTimetable.Text = "Pick a Semester"
        Me.LblViewTimetable.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.LblViewTimetable)
        Me.Panel2.Controls.Add(Me.LblHome)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 49)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(777, 43)
        Me.Panel2.TabIndex = 29
        '
        'Panel3
        '
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Location = New System.Drawing.Point(26, 100)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(739, 334)
        Me.Panel3.TabIndex = 30
        '
        'PickSemCreate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(777, 484)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.BtnSemester3)
        Me.Controls.Add(Me.BtnSemester2)
        Me.Controls.Add(Me.BtnSemester1)
        Me.Controls.Add(Me.LblInstructions)
        Me.Controls.Add(Me.LblClassSize)
        Me.Controls.Add(Me.TxtClassSize)
        Me.Controls.Add(Me.TxtCredits)
        Me.Controls.Add(Me.LblCredits)
        Me.Controls.Add(Me.LblNext)
        Me.Controls.Add(Me.LblDelete)
        Me.Controls.Add(Me.BtnDelete)
        Me.Controls.Add(Me.BtnAdd)
        Me.Controls.Add(Me.CmbType)
        Me.Controls.Add(Me.LblCrsType)
        Me.Controls.Add(Me.LblCrsTitle)
        Me.Controls.Add(Me.LblCrsCode)
        Me.Controls.Add(Me.TxtCrsTitle)
        Me.Controls.Add(Me.TxtCrsCode)
        Me.Controls.Add(Me.LsbCourses)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "PickSemCreate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pick a Semester"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents LsbCourses As ListBox
    Friend WithEvents TxtCrsCode As TextBox
    Friend WithEvents TxtCrsTitle As TextBox
    Friend WithEvents LblCrsCode As Label
    Friend WithEvents LblCrsTitle As Label
    Friend WithEvents LblCrsType As Label
    Friend WithEvents CmbType As ComboBox
    Friend WithEvents BtnAdd As Button
    Friend WithEvents BtnDelete As Button
    Friend WithEvents LblDelete As Label
    Friend WithEvents LblNext As LinkLabel
    Friend WithEvents LblHome As LinkLabel
    Friend WithEvents LblCredits As Label
    Friend WithEvents TxtCredits As TextBox
    Friend WithEvents TxtClassSize As TextBox
    Friend WithEvents LblClassSize As Label
    Friend WithEvents LblLogout As LinkLabel
    Friend WithEvents BtnSemester3 As RadioButton
    Friend WithEvents BtnSemester2 As RadioButton
    Friend WithEvents BtnSemester1 As RadioButton
    Friend WithEvents LblInstructions As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents LblViewTimetable As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
End Class

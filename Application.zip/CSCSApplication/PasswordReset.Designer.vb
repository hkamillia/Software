﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PasswordReset
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PasswordReset))
        Me.LblLogin = New System.Windows.Forms.LinkLabel()
        Me.LblResetPassword = New System.Windows.Forms.Label()
        Me.LblInstruction = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.TxtPasswordRetype = New System.Windows.Forms.TextBox()
        Me.LblPasswordRetype = New System.Windows.Forms.Label()
        Me.TxtPassword = New System.Windows.Forms.TextBox()
        Me.LblPassInstruction = New System.Windows.Forms.Label()
        Me.LblPassword = New System.Windows.Forms.Label()
        Me.LblLname = New System.Windows.Forms.Label()
        Me.LblFname = New System.Windows.Forms.Label()
        Me.TxtLname = New System.Windows.Forms.TextBox()
        Me.TxtFname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LblLogin
        '
        Me.LblLogin.AutoSize = True
        Me.LblLogin.BackColor = System.Drawing.Color.Transparent
        Me.LblLogin.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLogin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogin.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblLogin.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblLogin.LinkColor = System.Drawing.Color.DarkGreen
        Me.LblLogin.Location = New System.Drawing.Point(582, 58)
        Me.LblLogin.Name = "LblLogin"
        Me.LblLogin.Size = New System.Drawing.Size(130, 18)
        Me.LblLogin.TabIndex = 32
        Me.LblLogin.TabStop = True
        Me.LblLogin.Text = "<<Return to Login"
        Me.LblLogin.VisitedLinkColor = System.Drawing.Color.Silver
        '
        'LblResetPassword
        '
        Me.LblResetPassword.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblResetPassword.AutoSize = True
        Me.LblResetPassword.BackColor = System.Drawing.Color.Ivory
        Me.LblResetPassword.Cursor = System.Windows.Forms.Cursors.Default
        Me.LblResetPassword.Font = New System.Drawing.Font("Papyrus", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblResetPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.LblResetPassword.Location = New System.Drawing.Point(265, 91)
        Me.LblResetPassword.Name = "LblResetPassword"
        Me.LblResetPassword.Size = New System.Drawing.Size(156, 30)
        Me.LblResetPassword.TabIndex = 33
        Me.LblResetPassword.Text = "Reset Password"
        '
        'LblInstruction
        '
        Me.LblInstruction.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblInstruction.AutoSize = True
        Me.LblInstruction.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblInstruction.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblInstruction.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.LblInstruction.Location = New System.Drawing.Point(84, 135)
        Me.LblInstruction.Name = "LblInstruction"
        Me.LblInstruction.Size = New System.Drawing.Size(507, 47)
        Me.LblInstruction.TabIndex = 34
        Me.LblInstruction.Text = "If you forgot your password, you will need to reset it. In order to reset it plea" &
    "se enter your " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "First and Last names, then enter your New Password and confirm i" &
    "t." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.BtnReset)
        Me.Panel1.Controls.Add(Me.TxtPasswordRetype)
        Me.Panel1.Controls.Add(Me.LblPasswordRetype)
        Me.Panel1.Controls.Add(Me.TxtPassword)
        Me.Panel1.Controls.Add(Me.LblPassInstruction)
        Me.Panel1.Controls.Add(Me.LblPassword)
        Me.Panel1.Controls.Add(Me.LblLname)
        Me.Panel1.Controls.Add(Me.LblFname)
        Me.Panel1.Controls.Add(Me.TxtLname)
        Me.Panel1.Controls.Add(Me.TxtFname)
        Me.Panel1.Location = New System.Drawing.Point(45, 183)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(591, 252)
        Me.Panel1.TabIndex = 35
        '
        'BtnReset
        '
        Me.BtnReset.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnReset.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnReset.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnReset.Location = New System.Drawing.Point(465, 194)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(71, 23)
        Me.BtnReset.TabIndex = 32
        Me.BtnReset.Text = "Reset"
        Me.BtnReset.UseVisualStyleBackColor = False
        '
        'TxtPasswordRetype
        '
        Me.TxtPasswordRetype.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtPasswordRetype.Location = New System.Drawing.Point(226, 197)
        Me.TxtPasswordRetype.Name = "TxtPasswordRetype"
        Me.TxtPasswordRetype.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.TxtPasswordRetype.Size = New System.Drawing.Size(219, 20)
        Me.TxtPasswordRetype.TabIndex = 31
        '
        'LblPasswordRetype
        '
        Me.LblPasswordRetype.AutoSize = True
        Me.LblPasswordRetype.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPasswordRetype.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblPasswordRetype.Location = New System.Drawing.Point(93, 201)
        Me.LblPasswordRetype.Name = "LblPasswordRetype"
        Me.LblPasswordRetype.Size = New System.Drawing.Size(118, 16)
        Me.LblPasswordRetype.TabIndex = 30
        Me.LblPasswordRetype.Text = "Retype Password:"
        '
        'TxtPassword
        '
        Me.TxtPassword.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtPassword.Location = New System.Drawing.Point(226, 160)
        Me.TxtPassword.Name = "TxtPassword"
        Me.TxtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.TxtPassword.Size = New System.Drawing.Size(219, 20)
        Me.TxtPassword.TabIndex = 29
        '
        'LblPassInstruction
        '
        Me.LblPassInstruction.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblPassInstruction.AutoSize = True
        Me.LblPassInstruction.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPassInstruction.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(159, Byte), Integer), CType(CType(72, Byte), Integer))
        Me.LblPassInstruction.Location = New System.Drawing.Point(106, 128)
        Me.LblPassInstruction.Name = "LblPassInstruction"
        Me.LblPassInstruction.Size = New System.Drawing.Size(406, 15)
        Me.LblPassInstruction.TabIndex = 28
        Me.LblPassInstruction.Text = "Please enter your new password and retype it for confirmation:"
        '
        'LblPassword
        '
        Me.LblPassword.AutoSize = True
        Me.LblPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPassword.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblPassword.Location = New System.Drawing.Point(110, 163)
        Me.LblPassword.Name = "LblPassword"
        Me.LblPassword.Size = New System.Drawing.Size(101, 16)
        Me.LblPassword.TabIndex = 7
        Me.LblPassword.Text = "New Password:"
        '
        'LblLname
        '
        Me.LblLname.AutoSize = True
        Me.LblLname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLname.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblLname.Location = New System.Drawing.Point(126, 88)
        Me.LblLname.Name = "LblLname"
        Me.LblLname.Size = New System.Drawing.Size(76, 16)
        Me.LblLname.TabIndex = 6
        Me.LblLname.Text = "Last Name:"
        '
        'LblFname
        '
        Me.LblFname.AutoSize = True
        Me.LblFname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFname.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblFname.Location = New System.Drawing.Point(126, 39)
        Me.LblFname.Name = "LblFname"
        Me.LblFname.Size = New System.Drawing.Size(76, 16)
        Me.LblFname.TabIndex = 5
        Me.LblFname.Text = "First Name:"
        '
        'TxtLname
        '
        Me.TxtLname.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtLname.Location = New System.Drawing.Point(226, 85)
        Me.TxtLname.Name = "TxtLname"
        Me.TxtLname.Size = New System.Drawing.Size(216, 20)
        Me.TxtLname.TabIndex = 2
        '
        'TxtFname
        '
        Me.TxtFname.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtFname.Location = New System.Drawing.Point(226, 35)
        Me.TxtFname.Name = "TxtFname"
        Me.TxtFname.Size = New System.Drawing.Size(215, 20)
        Me.TxtFname.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Ivory
        Me.Label1.Image = CType(resources.GetObject("Label1.Image"), System.Drawing.Image)
        Me.Label1.Location = New System.Drawing.Point(128, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(431, 33)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Computer Science Course Scheduler"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(719, 43)
        Me.Panel2.TabIndex = 37
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.LightGray
        Me.PictureBox1.Image = Global.CSCSApplication.My.Resources.Resources.light_usc_logo
        Me.PictureBox1.Location = New System.Drawing.Point(2, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(57, 44)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PasswordReset
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(719, 452)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.LblInstruction)
        Me.Controls.Add(Me.LblResetPassword)
        Me.Controls.Add(Me.LblLogin)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "PasswordReset"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Password Reset"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblLogin As LinkLabel
    Friend WithEvents LblResetPassword As Label
    Friend WithEvents LblInstruction As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TxtFname As TextBox
    Friend WithEvents TxtLname As TextBox
    Friend WithEvents LblFname As Label
    Friend WithEvents LblLname As Label
    Friend WithEvents LblPassInstruction As Label
    Friend WithEvents LblPassword As Label
    Friend WithEvents TxtPassword As TextBox
    Friend WithEvents LblPasswordRetype As Label
    Friend WithEvents TxtPasswordRetype As TextBox
    Friend WithEvents BtnReset As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
End Class

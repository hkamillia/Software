﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UpdateTimetable
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UpdateTimetable))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LblCSCS = New System.Windows.Forms.Label()
        Me.LblLogout = New System.Windows.Forms.LinkLabel()
        Me.LblHome = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.LblUpdateTimetable = New System.Windows.Forms.Label()
        Me.BtnSemester1 = New System.Windows.Forms.RadioButton()
        Me.BtnSemester2 = New System.Windows.Forms.RadioButton()
        Me.BtnSemester3 = New System.Windows.Forms.RadioButton()
        Me.DgdTimetable = New System.Windows.Forms.DataGridView()
        Me.TxtCrsCode = New System.Windows.Forms.TextBox()
        Me.BtnSearch = New System.Windows.Forms.Button()
        Me.LblCrsCode = New System.Windows.Forms.Label()
        Me.TxtCrsTitle = New System.Windows.Forms.TextBox()
        Me.LblCrsTitle = New System.Windows.Forms.Label()
        Me.TxtCredits = New System.Windows.Forms.TextBox()
        Me.LblCredits = New System.Windows.Forms.Label()
        Me.LblDays = New System.Windows.Forms.Label()
        Me.CmbDays = New System.Windows.Forms.ComboBox()
        Me.LblTime = New System.Windows.Forms.Label()
        Me.CmbTimes = New System.Windows.Forms.ComboBox()
        Me.LblLab = New System.Windows.Forms.Label()
        Me.CmbLabs = New System.Windows.Forms.ComboBox()
        Me.BtnUpdate = New System.Windows.Forms.Button()
        Me.LblLecturer = New System.Windows.Forms.Label()
        Me.TxtLecturer = New System.Windows.Forms.TextBox()
        Me.CmbLecturers = New System.Windows.Forms.ComboBox()
        Me.LblNewLecturer = New System.Windows.Forms.Label()
        Me.BtnUpdateLect = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Sem_txtbox = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.DgdTimetable, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.Controls.Add(Me.LblCSCS)
        Me.Panel1.Controls.Add(Me.LblLogout)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(912, 49)
        Me.Panel1.TabIndex = 5
        '
        'LblCSCS
        '
        Me.LblCSCS.AutoSize = True
        Me.LblCSCS.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCSCS.ForeColor = System.Drawing.Color.Ivory
        Me.LblCSCS.Image = CType(resources.GetObject("LblCSCS.Image"), System.Drawing.Image)
        Me.LblCSCS.Location = New System.Drawing.Point(235, 9)
        Me.LblCSCS.Name = "LblCSCS"
        Me.LblCSCS.Size = New System.Drawing.Size(440, 31)
        Me.LblCSCS.TabIndex = 33
        Me.LblCSCS.Text = "Computer Science Course Scheduler"
        '
        'LblLogout
        '
        Me.LblLogout.ActiveLinkColor = System.Drawing.Color.OliveDrab
        Me.LblLogout.AutoSize = True
        Me.LblLogout.BackColor = System.Drawing.Color.Transparent
        Me.LblLogout.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogout.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblLogout.LinkColor = System.Drawing.Color.OliveDrab
        Me.LblLogout.Location = New System.Drawing.Point(812, 16)
        Me.LblLogout.Name = "LblLogout"
        Me.LblLogout.Size = New System.Drawing.Size(84, 22)
        Me.LblLogout.TabIndex = 9
        Me.LblLogout.TabStop = True
        Me.LblLogout.Text = "LOGOUT"
        '
        'LblHome
        '
        Me.LblHome.AutoSize = True
        Me.LblHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHome.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblHome.LinkColor = System.Drawing.Color.DarkGreen
        Me.LblHome.Location = New System.Drawing.Point(765, 12)
        Me.LblHome.Name = "LblHome"
        Me.LblHome.Size = New System.Drawing.Size(131, 16)
        Me.LblHome.TabIndex = 32
        Me.LblHome.TabStop = True
        Me.LblHome.Text = "<<Return to Home"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.PictureBox1.Image = Global.CSCSApplication.My.Resources.Resources.light_usc_logo
        Me.PictureBox1.Location = New System.Drawing.Point(1, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(74, 43)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.LblUpdateTimetable)
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.LblHome)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 49)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(912, 43)
        Me.Panel2.TabIndex = 6
        '
        'LblUpdateTimetable
        '
        Me.LblUpdateTimetable.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblUpdateTimetable.AutoSize = True
        Me.LblUpdateTimetable.BackColor = System.Drawing.Color.Transparent
        Me.LblUpdateTimetable.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblUpdateTimetable.ForeColor = System.Drawing.Color.Black
        Me.LblUpdateTimetable.Location = New System.Drawing.Point(360, 9)
        Me.LblUpdateTimetable.Name = "LblUpdateTimetable"
        Me.LblUpdateTimetable.Size = New System.Drawing.Size(174, 24)
        Me.LblUpdateTimetable.TabIndex = 0
        Me.LblUpdateTimetable.Text = "Update Timetable"
        Me.LblUpdateTimetable.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'BtnSemester1
        '
        Me.BtnSemester1.AutoSize = True
        Me.BtnSemester1.BackColor = System.Drawing.Color.Silver
        Me.BtnSemester1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSemester1.Font = New System.Drawing.Font("MS Reference Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSemester1.Location = New System.Drawing.Point(13, 133)
        Me.BtnSemester1.Name = "BtnSemester1"
        Me.BtnSemester1.Size = New System.Drawing.Size(114, 20)
        Me.BtnSemester1.TabIndex = 2
        Me.BtnSemester1.Text = "1st Semester"
        Me.BtnSemester1.UseVisualStyleBackColor = False
        '
        'BtnSemester2
        '
        Me.BtnSemester2.AutoSize = True
        Me.BtnSemester2.BackColor = System.Drawing.Color.Silver
        Me.BtnSemester2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSemester2.Font = New System.Drawing.Font("MS Reference Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSemester2.Location = New System.Drawing.Point(127, 133)
        Me.BtnSemester2.Name = "BtnSemester2"
        Me.BtnSemester2.Size = New System.Drawing.Size(117, 20)
        Me.BtnSemester2.TabIndex = 3
        Me.BtnSemester2.Text = "2nd Semester"
        Me.BtnSemester2.UseVisualStyleBackColor = False
        '
        'BtnSemester3
        '
        Me.BtnSemester3.AutoSize = True
        Me.BtnSemester3.BackColor = System.Drawing.Color.Silver
        Me.BtnSemester3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSemester3.Font = New System.Drawing.Font("MS Reference Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSemester3.Location = New System.Drawing.Point(244, 133)
        Me.BtnSemester3.Name = "BtnSemester3"
        Me.BtnSemester3.Size = New System.Drawing.Size(114, 20)
        Me.BtnSemester3.TabIndex = 4
        Me.BtnSemester3.Text = "3rd Semester"
        Me.BtnSemester3.UseVisualStyleBackColor = False
        '
        'DgdTimetable
        '
        Me.DgdTimetable.AllowUserToAddRows = False
        Me.DgdTimetable.AllowUserToDeleteRows = False
        Me.DgdTimetable.AllowUserToOrderColumns = True
        Me.DgdTimetable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgdTimetable.GridColor = System.Drawing.Color.Honeydew
        Me.DgdTimetable.Location = New System.Drawing.Point(368, 134)
        Me.DgdTimetable.Name = "DgdTimetable"
        Me.DgdTimetable.ReadOnly = True
        Me.DgdTimetable.Size = New System.Drawing.Size(532, 345)
        Me.DgdTimetable.TabIndex = 7
        '
        'TxtCrsCode
        '
        Me.TxtCrsCode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCrsCode.Location = New System.Drawing.Point(131, 158)
        Me.TxtCrsCode.Name = "TxtCrsCode"
        Me.TxtCrsCode.Size = New System.Drawing.Size(146, 20)
        Me.TxtCrsCode.TabIndex = 8
        '
        'BtnSearch
        '
        Me.BtnSearch.BackColor = System.Drawing.Color.Silver
        Me.BtnSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSearch.Location = New System.Drawing.Point(281, 156)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.Size = New System.Drawing.Size(75, 23)
        Me.BtnSearch.TabIndex = 9
        Me.BtnSearch.Text = "Search"
        Me.BtnSearch.UseVisualStyleBackColor = False
        '
        'LblCrsCode
        '
        Me.LblCrsCode.AutoSize = True
        Me.LblCrsCode.BackColor = System.Drawing.Color.Transparent
        Me.LblCrsCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblCrsCode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblCrsCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCrsCode.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblCrsCode.Location = New System.Drawing.Point(6, 8)
        Me.LblCrsCode.Name = "LblCrsCode"
        Me.LblCrsCode.Size = New System.Drawing.Size(104, 18)
        Me.LblCrsCode.TabIndex = 10
        Me.LblCrsCode.Text = "Course Code:"
        '
        'TxtCrsTitle
        '
        Me.TxtCrsTitle.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCrsTitle.Location = New System.Drawing.Point(131, 196)
        Me.TxtCrsTitle.Name = "TxtCrsTitle"
        Me.TxtCrsTitle.Size = New System.Drawing.Size(203, 20)
        Me.TxtCrsTitle.TabIndex = 11
        '
        'LblCrsTitle
        '
        Me.LblCrsTitle.AutoSize = True
        Me.LblCrsTitle.BackColor = System.Drawing.Color.Transparent
        Me.LblCrsTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblCrsTitle.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblCrsTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCrsTitle.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblCrsTitle.Location = New System.Drawing.Point(5, 45)
        Me.LblCrsTitle.Name = "LblCrsTitle"
        Me.LblCrsTitle.Size = New System.Drawing.Size(98, 18)
        Me.LblCrsTitle.TabIndex = 12
        Me.LblCrsTitle.Text = "Course Title:"
        '
        'TxtCredits
        '
        Me.TxtCredits.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCredits.Location = New System.Drawing.Point(131, 239)
        Me.TxtCredits.Name = "TxtCredits"
        Me.TxtCredits.Size = New System.Drawing.Size(86, 20)
        Me.TxtCredits.TabIndex = 13
        '
        'LblCredits
        '
        Me.LblCredits.AutoSize = True
        Me.LblCredits.BackColor = System.Drawing.Color.Transparent
        Me.LblCredits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblCredits.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblCredits.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCredits.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblCredits.Location = New System.Drawing.Point(6, 88)
        Me.LblCredits.Name = "LblCredits"
        Me.LblCredits.Size = New System.Drawing.Size(63, 18)
        Me.LblCredits.TabIndex = 14
        Me.LblCredits.Text = "Credits:"
        '
        'LblDays
        '
        Me.LblDays.AutoSize = True
        Me.LblDays.BackColor = System.Drawing.Color.Transparent
        Me.LblDays.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblDays.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDays.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblDays.Location = New System.Drawing.Point(6, 128)
        Me.LblDays.Name = "LblDays"
        Me.LblDays.Size = New System.Drawing.Size(50, 18)
        Me.LblDays.TabIndex = 15
        Me.LblDays.Text = "Days:"
        '
        'CmbDays
        '
        Me.CmbDays.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CmbDays.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbDays.FormattingEnabled = True
        Me.CmbDays.Items.AddRange(New Object() {"M/W", "Tu/Th"})
        Me.CmbDays.Location = New System.Drawing.Point(129, 277)
        Me.CmbDays.Name = "CmbDays"
        Me.CmbDays.Size = New System.Drawing.Size(148, 21)
        Me.CmbDays.TabIndex = 16
        '
        'LblTime
        '
        Me.LblTime.AutoSize = True
        Me.LblTime.BackColor = System.Drawing.Color.Transparent
        Me.LblTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblTime.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTime.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblTime.Location = New System.Drawing.Point(7, 165)
        Me.LblTime.Name = "LblTime"
        Me.LblTime.Size = New System.Drawing.Size(49, 18)
        Me.LblTime.TabIndex = 17
        Me.LblTime.Text = "Time:"
        '
        'CmbTimes
        '
        Me.CmbTimes.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CmbTimes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbTimes.FormattingEnabled = True
        Me.CmbTimes.Items.AddRange(New Object() {"8:00AM-9:15AM", "9:25AM-10:40AM", "10:50AM-12:05PM", "12:15PM-1:30PM", "1:40PM-2:55PM", "3:05PM-4:20PM", "4:30PM-5:45PM", "5:55PM-7:10PM", "7:20PM-8:35PM"})
        Me.CmbTimes.Location = New System.Drawing.Point(128, 315)
        Me.CmbTimes.Name = "CmbTimes"
        Me.CmbTimes.Size = New System.Drawing.Size(188, 21)
        Me.CmbTimes.TabIndex = 23
        '
        'LblLab
        '
        Me.LblLab.AutoSize = True
        Me.LblLab.BackColor = System.Drawing.Color.Transparent
        Me.LblLab.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLab.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblLab.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLab.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblLab.Location = New System.Drawing.Point(6, 206)
        Me.LblLab.Name = "LblLab"
        Me.LblLab.Size = New System.Drawing.Size(40, 18)
        Me.LblLab.TabIndex = 24
        Me.LblLab.Text = "Lab:"
        '
        'CmbLabs
        '
        Me.CmbLabs.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CmbLabs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbLabs.FormattingEnabled = True
        Me.CmbLabs.Location = New System.Drawing.Point(126, 356)
        Me.CmbLabs.Name = "CmbLabs"
        Me.CmbLabs.Size = New System.Drawing.Size(121, 21)
        Me.CmbLabs.TabIndex = 25
        '
        'BtnUpdate
        '
        Me.BtnUpdate.BackColor = System.Drawing.Color.Silver
        Me.BtnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnUpdate.Location = New System.Drawing.Point(242, 202)
        Me.BtnUpdate.Name = "BtnUpdate"
        Me.BtnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.BtnUpdate.TabIndex = 26
        Me.BtnUpdate.Text = "Update"
        Me.BtnUpdate.UseVisualStyleBackColor = False
        '
        'LblLecturer
        '
        Me.LblLecturer.AutoSize = True
        Me.LblLecturer.BackColor = System.Drawing.Color.Transparent
        Me.LblLecturer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLecturer.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblLecturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLecturer.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblLecturer.Location = New System.Drawing.Point(5, 248)
        Me.LblLecturer.Name = "LblLecturer"
        Me.LblLecturer.Size = New System.Drawing.Size(70, 18)
        Me.LblLecturer.TabIndex = 27
        Me.LblLecturer.Text = "Lecturer:"
        '
        'TxtLecturer
        '
        Me.TxtLecturer.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtLecturer.Location = New System.Drawing.Point(127, 400)
        Me.TxtLecturer.Name = "TxtLecturer"
        Me.TxtLecturer.Size = New System.Drawing.Size(146, 20)
        Me.TxtLecturer.TabIndex = 28
        '
        'CmbLecturers
        '
        Me.CmbLecturers.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CmbLecturers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbLecturers.FormattingEnabled = True
        Me.CmbLecturers.Location = New System.Drawing.Point(126, 439)
        Me.CmbLecturers.Name = "CmbLecturers"
        Me.CmbLecturers.Size = New System.Drawing.Size(146, 21)
        Me.CmbLecturers.TabIndex = 29
        '
        'LblNewLecturer
        '
        Me.LblNewLecturer.AutoSize = True
        Me.LblNewLecturer.BackColor = System.Drawing.Color.Transparent
        Me.LblNewLecturer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblNewLecturer.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LblNewLecturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNewLecturer.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblNewLecturer.Location = New System.Drawing.Point(5, 286)
        Me.LblNewLecturer.Name = "LblNewLecturer"
        Me.LblNewLecturer.Size = New System.Drawing.Size(104, 18)
        Me.LblNewLecturer.TabIndex = 30
        Me.LblNewLecturer.Text = "New Lecturer:"
        '
        'BtnUpdateLect
        '
        Me.BtnUpdateLect.BackColor = System.Drawing.Color.Silver
        Me.BtnUpdateLect.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnUpdateLect.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnUpdateLect.Location = New System.Drawing.Point(276, 437)
        Me.BtnUpdateLect.Name = "BtnUpdateLect"
        Me.BtnUpdateLect.Size = New System.Drawing.Size(75, 23)
        Me.BtnUpdateLect.TabIndex = 31
        Me.BtnUpdateLect.Text = "Update"
        Me.BtnUpdateLect.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Silver
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(768, 110)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(124, 23)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "Save as PDF"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.BtnUpdate)
        Me.Panel3.Controls.Add(Me.LblCrsCode)
        Me.Panel3.Controls.Add(Me.LblNewLecturer)
        Me.Panel3.Controls.Add(Me.LblCrsTitle)
        Me.Panel3.Controls.Add(Me.LblCredits)
        Me.Panel3.Controls.Add(Me.LblDays)
        Me.Panel3.Controls.Add(Me.LblLecturer)
        Me.Panel3.Controls.Add(Me.LblTime)
        Me.Panel3.Controls.Add(Me.LblLab)
        Me.Panel3.Location = New System.Drawing.Point(12, 157)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(350, 318)
        Me.Panel3.TabIndex = 34
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Green
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(688, 97)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 13)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "e.g. 2014-2015"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(535, 95)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(154, 15)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "Insert Semester Period"
        '
        'Sem_txtbox
        '
        Me.Sem_txtbox.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Sem_txtbox.Location = New System.Drawing.Point(533, 112)
        Me.Sem_txtbox.Name = "Sem_txtbox"
        Me.Sem_txtbox.Size = New System.Drawing.Size(236, 20)
        Me.Sem_txtbox.TabIndex = 37
        '
        'UpdateTimetable
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(912, 503)
        Me.Controls.Add(Me.Sem_txtbox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.BtnUpdateLect)
        Me.Controls.Add(Me.CmbLecturers)
        Me.Controls.Add(Me.TxtLecturer)
        Me.Controls.Add(Me.CmbLabs)
        Me.Controls.Add(Me.CmbTimes)
        Me.Controls.Add(Me.CmbDays)
        Me.Controls.Add(Me.TxtCredits)
        Me.Controls.Add(Me.TxtCrsTitle)
        Me.Controls.Add(Me.BtnSearch)
        Me.Controls.Add(Me.TxtCrsCode)
        Me.Controls.Add(Me.DgdTimetable)
        Me.Controls.Add(Me.BtnSemester3)
        Me.Controls.Add(Me.BtnSemester2)
        Me.Controls.Add(Me.BtnSemester1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "UpdateTimetable"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Update Timetable"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.DgdTimetable, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents LblUpdateTimetable As Label
    Friend WithEvents BtnSemester1 As RadioButton
    Friend WithEvents BtnSemester2 As RadioButton
    Friend WithEvents BtnSemester3 As RadioButton
    Friend WithEvents DgdTimetable As DataGridView
    Friend WithEvents TxtCrsCode As TextBox
    Friend WithEvents BtnSearch As Button
    Friend WithEvents LblCrsCode As Label
    Friend WithEvents TxtCrsTitle As TextBox
    Friend WithEvents LblCrsTitle As Label
    Friend WithEvents TxtCredits As TextBox
    Friend WithEvents LblCredits As Label
    Friend WithEvents LblDays As Label
    Friend WithEvents CmbDays As ComboBox
    Friend WithEvents LblTime As Label
    Friend WithEvents CmbTimes As ComboBox
    Friend WithEvents LblLab As Label
    Friend WithEvents CmbLabs As ComboBox
    Friend WithEvents BtnUpdate As Button
    Friend WithEvents LblLecturer As Label
    Friend WithEvents TxtLecturer As TextBox
    Friend WithEvents CmbLecturers As ComboBox
    Friend WithEvents LblNewLecturer As Label
    Friend WithEvents BtnUpdateLect As Button
    Friend WithEvents LblHome As LinkLabel
    Friend WithEvents LblLogout As LinkLabel
    Friend WithEvents Button1 As Button
    Friend WithEvents LblCSCS As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Sem_txtbox As TextBox
End Class

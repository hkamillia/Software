﻿Imports System.Data.OleDb
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.IO
Public Class ViewTimetableCreate

    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Public myConnection As OleDbConnection = New OleDbConnection
    Dim da As OleDbDataAdapter
    Public dr As OleDbDataReader
    Dim ds As DataSet
    Dim tables As DataTableCollection
    Dim source1 As New BindingSource
    Dim txt As String
    Dim sem As String

    Private Sub ViewTimetableCreate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadForm()
    End Sub

    Private Sub LoadForm()
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        dataFile = "|DataDirectory|\Database\CSCSdb.mdb"
        connString = provider & dataFile
        myConnection.ConnectionString = connString
        LoadData()
    End Sub

    Private Sub LoadData()
        'Reads from database and fills data grid view
        myConnection.Open()
        ds = New DataSet
        tables = ds.Tables
        da = New OleDbDataAdapter("Select CourseCode, CourseTitle, Credits, Days, Time, Lab, Lecturer from [timetable] WHERE Semester='" & PickSemCreate.semester & "'", myConnection)
        da.Fill(ds, "timetable")
        Dim view As New DataView(tables(0))
        source1.DataSource = view
        Me.DgdTimetable.DataSource = view
        myConnection.Close()
    End Sub

    Private Sub LblBack_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LblBack.LinkClicked
        Hide()
        Dim MyForm As New CreateTimetable
        MyForm.Show()
    End Sub

    Private Sub LblHome_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LblHome.LinkClicked
        Hide()
        Main.Show()
    End Sub

    Private Sub LblLogout_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LblLogout.LinkClicked
        Main.Logout()
    End Sub

    Private Sub LblViewTimetable_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub DgdTimetable_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgdTimetable.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Save_btn.Click
        'Creating iTextSharp Table from the DataTable data
        Dim pdfTable As New PdfPTable(DgdTimetable.ColumnCount)
        pdfTable.DefaultCell.Padding = 3
        pdfTable.WidthPercentage = 60
        pdfTable.HorizontalAlignment = Element.ALIGN_LEFT
        pdfTable.DefaultCell.BorderWidth = 1

        'Adding Header row
        For Each column As DataGridViewColumn In DgdTimetable.Columns
            Dim cell As New PdfPCell(New Phrase(column.HeaderText))
            cell.BackgroundColor = New iTextSharp.text.BaseColor(64, 139, 40)
            pdfTable.AddCell(cell)
        Next

        'Adding DataRow
        For Each row As DataGridViewRow In DgdTimetable.Rows
            For Each cell As DataGridViewCell In row.Cells
                pdfTable.AddCell(cell.Value.ToString())
            Next
        Next

        'Exporting to PDF
        Dim folderPath As String = "C:\PDFs\"   'create absolute path to C:'
        If Not Directory.Exists(folderPath) Then
            Directory.CreateDirectory(folderPath)
        End If
        sem = PickSemCreate.semester
        Using stream As New FileStream(folderPath + Sem_txtbox.Text + " " + "Semester" + " " + sem + " " & "Timetable.pdf", FileMode.Create)
            Dim pdfDoc As New Document(PageSize.A2, 10.0F, 10.0F, 10.0F, 0.0F)
            PdfWriter.GetInstance(pdfDoc, stream)
            pdfDoc.Open()
            pdfDoc.Add(pdfTable)
            pdfDoc.Close()
            stream.Close()
        End Using

        'read file'
        txt = Sem_txtbox.Text

        If My.Computer.FileSystem.FileExists("C:\PDFs\" & txt & " " & "Semester" & " " & sem & " " & "Timetable" & ".pdf") Then
            Try
                Process.Start("acrobat", "C:\PDFs\" & txt & " " & "Semester" & " " & sem & " " & "Timetable" & ".pdf")

            Catch ex As Exception
                Try
                    Process.Start("AcroRd32", "C:\PDFs\" & txt & " " & "Semester" & " " & sem & " " & "Timetable" & ".pdf")
                Catch ex2 As Exception
                    Try
                        Process.Start("C:\PDFs\" & txt & " " & "Semester" & " " & sem & " " & "Timetable" & ".pdf")
                    Catch ex3 As Exception
                        MsgBox("Instal Acrobat Reader")
                    End Try
                End Try
            End Try
        Else
            MsgBox("File not found.")
        End If

    End Sub
End Class
﻿Imports System.Data.OleDb
Imports itextsharp.text
Imports itextsharp.text.pdf
Imports System.IO



Public Class ViewTimetables
    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Public myConnection As OleDbConnection = New OleDbConnection
    Dim da As OleDbDataAdapter
    Public dr As OleDbDataReader
    Dim ds As DataSet
    Dim tables As DataTableCollection
    Dim source1 As New BindingSource
    Public semester As String

    Private Sub ViewTimetables_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadForm()
    End Sub

    Private Sub LoadForm()
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        dataFile = "|DataDirectory|\Database\CSCSdb.mdb"
        connString = provider & dataFile
        myConnection.ConnectionString = connString
    End Sub

    Private Sub BtnSemester1_CheckedChanged(sender As Object, e As EventArgs) Handles BtnSemester1.CheckedChanged
        semester = "1st"
        LoadData()
    End Sub

    Private Sub BtnSemester2_CheckedChanged(sender As Object, e As EventArgs) Handles BtnSemester2.CheckedChanged
        semester = "2nd"
        LoadData()
    End Sub

    Private Sub BtnSemester3_CheckedChanged(sender As Object, e As EventArgs) Handles BtnSemester3.CheckedChanged
        semester = "3rd"
        LoadData()
    End Sub

    Private Sub LoadData()
        'Reads from database and fills data grid view
        myConnection.Open()
        ds = New DataSet
        tables = ds.Tables
        da = New OleDbDataAdapter("Select CourseCode, CourseTitle, Credits, Days, Time, Lab, Lecturer from [timetable] WHERE Semester='" & semester & "'", myConnection)
        da.Fill(ds, "timetable")
        Dim view As New DataView(tables(0))
        source1.DataSource = view
        Me.DgdTimetable.DataSource = view
        myConnection.Close()
    End Sub

    Private Sub LblLogout_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LblLogout.LinkClicked
        Main.Logout()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Creating iTextSharp Table from the DataTable data
        Dim pdfTable As New PdfPTable(DgdTimetable.ColumnCount)
        pdfTable.DefaultCell.Padding = 3
        pdfTable.WidthPercentage = 60
        pdfTable.HorizontalAlignment = Element.ALIGN_LEFT
        pdfTable.DefaultCell.BorderWidth = 1

        'Adding Header row
        For Each column As DataGridViewColumn In DgdTimetable.Columns
            Dim cell As New PdfPCell(New Phrase(column.HeaderText))
            cell.BackgroundColor = New itextsharp.text.BaseColor(64, 139, 40)
            pdfTable.AddCell(cell)
        Next

        'Adding DataRow
        For Each row As DataGridViewRow In DgdTimetable.Rows
            For Each cell As DataGridViewCell In row.Cells
                pdfTable.AddCell(cell.Value.ToString())
            Next
        Next

        'Exporting to PDF
        Dim folderPath As String = "C:\PDFs\"   'create absolute path to C:'
        If Not Directory.Exists(folderPath) Then
            Directory.CreateDirectory(folderPath)
        End If
        Using stream As New FileStream(folderPath & "Timetable.pdf", FileMode.Create)
            Dim pdfDoc As New Document(PageSize.A2, 10.0F, 10.0F, 10.0F, 0.0F)
            PdfWriter.GetInstance(pdfDoc, stream)
            pdfDoc.Open()
            pdfDoc.Add(pdfTable)
            pdfDoc.Close()
            stream.Close()
        End Using

        'read file'
        If My.Computer.FileSystem.FileExists("C:\PDFs\Timetable.pdf") Then
            Try
                Process.Start("acrobat", "C:\PDFs\Timetable.pdf")
            Catch ex As Exception
                Try
                    Process.Start("AcroRd32", "C:\PDFs\Timetable.pdf")
                Catch ex2 As Exception
                    Try
                        Process.Start("C:\PDFs\Timetable.pdf")
                    Catch ex3 As Exception
                        MsgBox("Instal Acrobat Reader")
                    End Try
                End Try
            End Try
        Else
            MsgBox("File not found.")
        End If


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub LblHome_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LblHome.LinkClicked
        Hide()
        Main.Show()
    End Sub
End Class
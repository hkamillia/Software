﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Users
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Users))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LblLogin = New System.Windows.Forms.LinkLabel()
        Me.LblCSCS = New System.Windows.Forms.Label()
        Me.DeleteUser = New System.Windows.Forms.TabPage()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BtnDelete = New System.Windows.Forms.Button()
        Me.TxtPassword2 = New System.Windows.Forms.TextBox()
        Me.TxtLname2 = New System.Windows.Forms.TextBox()
        Me.TxtFname2 = New System.Windows.Forms.TextBox()
        Me.LblPassword2 = New System.Windows.Forms.Label()
        Me.LblLname2 = New System.Windows.Forms.Label()
        Me.LblFname2 = New System.Windows.Forms.Label()
        Me.TabUsers = New System.Windows.Forms.TabControl()
        Me.AddUser = New System.Windows.Forms.TabPage()
        Me.LblInstruction = New System.Windows.Forms.Label()
        Me.BtnSubmit = New System.Windows.Forms.Button()
        Me.LblPasswordRetype = New System.Windows.Forms.Label()
        Me.LblPassword = New System.Windows.Forms.Label()
        Me.LblLname = New System.Windows.Forms.Label()
        Me.LblFname = New System.Windows.Forms.Label()
        Me.TxtPasswordRetype = New System.Windows.Forms.TextBox()
        Me.TxtPassword = New System.Windows.Forms.TextBox()
        Me.TxtLname = New System.Windows.Forms.TextBox()
        Me.TxtFname = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DeleteUser.SuspendLayout()
        Me.TabUsers.SuspendLayout()
        Me.AddUser.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(86, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(80, 80)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'LblLogin
        '
        Me.LblLogin.AutoSize = True
        Me.LblLogin.BackColor = System.Drawing.Color.Silver
        Me.LblLogin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LblLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogin.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblLogin.LinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LblLogin.Location = New System.Drawing.Point(14, 257)
        Me.LblLogin.Name = "LblLogin"
        Me.LblLogin.Size = New System.Drawing.Size(137, 20)
        Me.LblLogin.TabIndex = 31
        Me.LblLogin.TabStop = True
        Me.LblLogin.Text = "<<Return to Login"
        '
        'LblCSCS
        '
        Me.LblCSCS.AutoSize = True
        Me.LblCSCS.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCSCS.ForeColor = System.Drawing.Color.Ivory
        Me.LblCSCS.Image = CType(resources.GetObject("LblCSCS.Image"), System.Drawing.Image)
        Me.LblCSCS.Location = New System.Drawing.Point(20, 44)
        Me.LblCSCS.Name = "LblCSCS"
        Me.LblCSCS.Size = New System.Drawing.Size(440, 31)
        Me.LblCSCS.TabIndex = 32
        Me.LblCSCS.Text = "Computer Science Course Scheduler"
        '
        'DeleteUser
        '
        Me.DeleteUser.Controls.Add(Me.Label2)
        Me.DeleteUser.Controls.Add(Me.BtnDelete)
        Me.DeleteUser.Controls.Add(Me.TxtPassword2)
        Me.DeleteUser.Controls.Add(Me.TxtLname2)
        Me.DeleteUser.Controls.Add(Me.TxtFname2)
        Me.DeleteUser.Controls.Add(Me.LblPassword2)
        Me.DeleteUser.Controls.Add(Me.LblLname2)
        Me.DeleteUser.Controls.Add(Me.LblFname2)
        Me.DeleteUser.Location = New System.Drawing.Point(4, 22)
        Me.DeleteUser.Name = "DeleteUser"
        Me.DeleteUser.Padding = New System.Windows.Forms.Padding(3)
        Me.DeleteUser.Size = New System.Drawing.Size(771, 310)
        Me.DeleteUser.TabIndex = 1
        Me.DeleteUser.Text = "Delete User"
        Me.DeleteUser.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.Label2.Location = New System.Drawing.Point(47, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(372, 45)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Your account is fully powered by your name and password." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Therefore, in order to" &
    " remove your account from the system," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " you must enter your First and Last name " &
    "as well as your password."
        '
        'BtnDelete
        '
        Me.BtnDelete.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDelete.Location = New System.Drawing.Point(221, 228)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(81, 29)
        Me.BtnDelete.TabIndex = 9
        Me.BtnDelete.Text = "Delete"
        Me.BtnDelete.UseVisualStyleBackColor = False
        '
        'TxtPassword2
        '
        Me.TxtPassword2.Location = New System.Drawing.Point(160, 190)
        Me.TxtPassword2.Name = "TxtPassword2"
        Me.TxtPassword2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.TxtPassword2.Size = New System.Drawing.Size(219, 20)
        Me.TxtPassword2.TabIndex = 8
        '
        'TxtLname2
        '
        Me.TxtLname2.Location = New System.Drawing.Point(160, 143)
        Me.TxtLname2.Name = "TxtLname2"
        Me.TxtLname2.Size = New System.Drawing.Size(219, 20)
        Me.TxtLname2.TabIndex = 2
        '
        'TxtFname2
        '
        Me.TxtFname2.Location = New System.Drawing.Point(160, 100)
        Me.TxtFname2.Name = "TxtFname2"
        Me.TxtFname2.Size = New System.Drawing.Size(219, 20)
        Me.TxtFname2.TabIndex = 1
        '
        'LblPassword2
        '
        Me.LblPassword2.AutoSize = True
        Me.LblPassword2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPassword2.Location = New System.Drawing.Point(81, 190)
        Me.LblPassword2.Name = "LblPassword2"
        Me.LblPassword2.Size = New System.Drawing.Size(73, 15)
        Me.LblPassword2.TabIndex = 7
        Me.LblPassword2.Text = "Password:"
        '
        'LblLname2
        '
        Me.LblLname2.AutoSize = True
        Me.LblLname2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLname2.Location = New System.Drawing.Point(76, 143)
        Me.LblLname2.Name = "LblLname2"
        Me.LblLname2.Size = New System.Drawing.Size(80, 15)
        Me.LblLname2.TabIndex = 6
        Me.LblLname2.Text = "Last Name:"
        '
        'LblFname2
        '
        Me.LblFname2.AutoSize = True
        Me.LblFname2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFname2.Location = New System.Drawing.Point(77, 103)
        Me.LblFname2.Name = "LblFname2"
        Me.LblFname2.Size = New System.Drawing.Size(81, 15)
        Me.LblFname2.TabIndex = 5
        Me.LblFname2.Text = "First Name:"
        '
        'TabUsers
        '
        Me.TabUsers.Controls.Add(Me.AddUser)
        Me.TabUsers.Controls.Add(Me.DeleteUser)
        Me.TabUsers.Location = New System.Drawing.Point(-2, 149)
        Me.TabUsers.Name = "TabUsers"
        Me.TabUsers.SelectedIndex = 0
        Me.TabUsers.Size = New System.Drawing.Size(779, 336)
        Me.TabUsers.TabIndex = 5
        '
        'AddUser
        '
        Me.AddUser.BackgroundImage = CType(resources.GetObject("AddUser.BackgroundImage"), System.Drawing.Image)
        Me.AddUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.AddUser.Controls.Add(Me.LblInstruction)
        Me.AddUser.Controls.Add(Me.BtnSubmit)
        Me.AddUser.Controls.Add(Me.LblPasswordRetype)
        Me.AddUser.Controls.Add(Me.LblPassword)
        Me.AddUser.Controls.Add(Me.LblLogin)
        Me.AddUser.Controls.Add(Me.LblLname)
        Me.AddUser.Controls.Add(Me.LblFname)
        Me.AddUser.Controls.Add(Me.TxtPasswordRetype)
        Me.AddUser.Controls.Add(Me.TxtPassword)
        Me.AddUser.Controls.Add(Me.TxtLname)
        Me.AddUser.Controls.Add(Me.TxtFname)
        Me.AddUser.Location = New System.Drawing.Point(4, 22)
        Me.AddUser.Name = "AddUser"
        Me.AddUser.Padding = New System.Windows.Forms.Padding(3)
        Me.AddUser.Size = New System.Drawing.Size(771, 310)
        Me.AddUser.TabIndex = 0
        Me.AddUser.Text = "Activate  Account"
        Me.AddUser.UseVisualStyleBackColor = True
        '
        'LblInstruction
        '
        Me.LblInstruction.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblInstruction.AutoSize = True
        Me.LblInstruction.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblInstruction.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.LblInstruction.Location = New System.Drawing.Point(15, 9)
        Me.LblInstruction.Name = "LblInstruction"
        Me.LblInstruction.Size = New System.Drawing.Size(414, 45)
        Me.LblInstruction.TabIndex = 9
        Me.LblInstruction.Text = "To activate your user account please enter your First name and Last name. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Then " &
    "enter your password and retype it for confirmation." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'BtnSubmit
        '
        Me.BtnSubmit.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BtnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSubmit.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnSubmit.Location = New System.Drawing.Point(217, 222)
        Me.BtnSubmit.Name = "BtnSubmit"
        Me.BtnSubmit.Size = New System.Drawing.Size(81, 29)
        Me.BtnSubmit.TabIndex = 8
        Me.BtnSubmit.Text = "Submit"
        Me.BtnSubmit.UseVisualStyleBackColor = False
        '
        'LblPasswordRetype
        '
        Me.LblPasswordRetype.AutoSize = True
        Me.LblPasswordRetype.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPasswordRetype.Location = New System.Drawing.Point(18, 192)
        Me.LblPasswordRetype.Name = "LblPasswordRetype"
        Me.LblPasswordRetype.Size = New System.Drawing.Size(121, 15)
        Me.LblPasswordRetype.TabIndex = 7
        Me.LblPasswordRetype.Text = "Retype Password:"
        '
        'LblPassword
        '
        Me.LblPassword.AutoSize = True
        Me.LblPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPassword.Location = New System.Drawing.Point(64, 147)
        Me.LblPassword.Name = "LblPassword"
        Me.LblPassword.Size = New System.Drawing.Size(73, 15)
        Me.LblPassword.TabIndex = 6
        Me.LblPassword.Text = "Password:"
        '
        'LblLname
        '
        Me.LblLname.AutoSize = True
        Me.LblLname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLname.Location = New System.Drawing.Point(59, 105)
        Me.LblLname.Name = "LblLname"
        Me.LblLname.Size = New System.Drawing.Size(80, 15)
        Me.LblLname.TabIndex = 5
        Me.LblLname.Text = "Last Name:"
        '
        'LblFname
        '
        Me.LblFname.AutoSize = True
        Me.LblFname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFname.Location = New System.Drawing.Point(59, 67)
        Me.LblFname.Name = "LblFname"
        Me.LblFname.Size = New System.Drawing.Size(81, 15)
        Me.LblFname.TabIndex = 4
        Me.LblFname.Text = "First Name:"
        '
        'TxtPasswordRetype
        '
        Me.TxtPasswordRetype.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtPasswordRetype.Location = New System.Drawing.Point(158, 187)
        Me.TxtPasswordRetype.Name = "TxtPasswordRetype"
        Me.TxtPasswordRetype.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.TxtPasswordRetype.Size = New System.Drawing.Size(219, 20)
        Me.TxtPasswordRetype.TabIndex = 3
        '
        'TxtPassword
        '
        Me.TxtPassword.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtPassword.Location = New System.Drawing.Point(158, 142)
        Me.TxtPassword.Name = "TxtPassword"
        Me.TxtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.TxtPassword.Size = New System.Drawing.Size(219, 20)
        Me.TxtPassword.TabIndex = 2
        '
        'TxtLname
        '
        Me.TxtLname.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtLname.Location = New System.Drawing.Point(158, 100)
        Me.TxtLname.Name = "TxtLname"
        Me.TxtLname.Size = New System.Drawing.Size(219, 20)
        Me.TxtLname.TabIndex = 1
        '
        'TxtFname
        '
        Me.TxtFname.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtFname.Location = New System.Drawing.Point(158, 64)
        Me.TxtFname.Name = "TxtFname"
        Me.TxtFname.Size = New System.Drawing.Size(219, 20)
        Me.TxtFname.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(479, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(269, 461)
        Me.Panel1.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 110)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(258, 130)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "MISSION" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "The University of the Southern Caribbean" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "seeks to transform ordinary " &
    "people into " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "extraordinary servants of God to humanity " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "through a holistic ter" &
    "tiary educational " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "experience." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(0, 370)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(258, 66)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "MOTTO" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Beyond Excellence............................................" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(1, 240)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(252, 130)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "VISION" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "A Seventh-day Adventist University fully " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "reflecting the character of " &
    "God through " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "spiritual, intellectual, physical, social and " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "cultural developme" &
    "nt." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Users
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(733, 457)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.LblCSCS)
        Me.Controls.Add(Me.TabUsers)
        Me.Name = "Users"
        Me.ShowIcon = False
        Me.Text = "Sign Up"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DeleteUser.ResumeLayout(False)
        Me.DeleteUser.PerformLayout()
        Me.TabUsers.ResumeLayout(False)
        Me.AddUser.ResumeLayout(False)
        Me.AddUser.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents LblLogin As LinkLabel
    Friend WithEvents LblCSCS As Label
    Friend WithEvents DeleteUser As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents BtnDelete As Button
    Friend WithEvents TxtPassword2 As TextBox
    Friend WithEvents TxtLname2 As TextBox
    Friend WithEvents TxtFname2 As TextBox
    Friend WithEvents LblPassword2 As Label
    Friend WithEvents LblLname2 As Label
    Friend WithEvents LblFname2 As Label
    Friend WithEvents TabUsers As TabControl
    Friend WithEvents AddUser As TabPage
    Friend WithEvents LblInstruction As Label
    Friend WithEvents BtnSubmit As Button
    Friend WithEvents LblPasswordRetype As Label
    Friend WithEvents LblPassword As Label
    Friend WithEvents LblLname As Label
    Friend WithEvents LblFname As Label
    Friend WithEvents TxtPasswordRetype As TextBox
    Friend WithEvents TxtPassword As TextBox
    Friend WithEvents TxtLname As TextBox
    Friend WithEvents TxtFname As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
End Class

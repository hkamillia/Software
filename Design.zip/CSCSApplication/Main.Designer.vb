﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.BtnLecturers = New System.Windows.Forms.Button()
        Me.BtnCreate = New System.Windows.Forms.Button()
        Me.BtnView = New System.Windows.Forms.Button()
        Me.BtnUpdate = New System.Windows.Forms.Button()
        Me.BtnDelete = New System.Windows.Forms.Button()
        Me.BtnLabs = New System.Windows.Forms.Button()
        Me.LblLogout = New System.Windows.Forms.LinkLabel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.LblViewTimetable = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LblAdmin = New System.Windows.Forms.Label()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnLecturers
        '
        Me.BtnLecturers.BackColor = System.Drawing.Color.Honeydew
        Me.BtnLecturers.BackgroundImage = CType(resources.GetObject("BtnLecturers.BackgroundImage"), System.Drawing.Image)
        Me.BtnLecturers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnLecturers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnLecturers.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLecturers.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnLecturers.Location = New System.Drawing.Point(416, 203)
        Me.BtnLecturers.Name = "BtnLecturers"
        Me.BtnLecturers.Size = New System.Drawing.Size(148, 40)
        Me.BtnLecturers.TabIndex = 1
        Me.BtnLecturers.Text = "Manage Lecturers"
        Me.BtnLecturers.UseVisualStyleBackColor = False
        '
        'BtnCreate
        '
        Me.BtnCreate.BackColor = System.Drawing.Color.Honeydew
        Me.BtnCreate.BackgroundImage = CType(resources.GetObject("BtnCreate.BackgroundImage"), System.Drawing.Image)
        Me.BtnCreate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCreate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnCreate.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreate.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnCreate.Location = New System.Drawing.Point(591, 203)
        Me.BtnCreate.Name = "BtnCreate"
        Me.BtnCreate.Size = New System.Drawing.Size(148, 40)
        Me.BtnCreate.TabIndex = 2
        Me.BtnCreate.Text = "Create Timetable"
        Me.BtnCreate.UseVisualStyleBackColor = False
        '
        'BtnView
        '
        Me.BtnView.BackColor = System.Drawing.Color.Honeydew
        Me.BtnView.BackgroundImage = CType(resources.GetObject("BtnView.BackgroundImage"), System.Drawing.Image)
        Me.BtnView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnView.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnView.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnView.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnView.Location = New System.Drawing.Point(591, 320)
        Me.BtnView.Name = "BtnView"
        Me.BtnView.Size = New System.Drawing.Size(148, 40)
        Me.BtnView.TabIndex = 3
        Me.BtnView.Text = "View Timetable"
        Me.BtnView.UseVisualStyleBackColor = False
        '
        'BtnUpdate
        '
        Me.BtnUpdate.BackColor = System.Drawing.Color.Honeydew
        Me.BtnUpdate.BackgroundImage = CType(resources.GetObject("BtnUpdate.BackgroundImage"), System.Drawing.Image)
        Me.BtnUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnUpdate.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnUpdate.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnUpdate.Location = New System.Drawing.Point(503, 387)
        Me.BtnUpdate.Name = "BtnUpdate"
        Me.BtnUpdate.Size = New System.Drawing.Size(148, 40)
        Me.BtnUpdate.TabIndex = 4
        Me.BtnUpdate.Text = "Update Timetable"
        Me.BtnUpdate.UseVisualStyleBackColor = False
        '
        'BtnDelete
        '
        Me.BtnDelete.BackColor = System.Drawing.Color.Honeydew
        Me.BtnDelete.BackgroundImage = CType(resources.GetObject("BtnDelete.BackgroundImage"), System.Drawing.Image)
        Me.BtnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnDelete.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDelete.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnDelete.Location = New System.Drawing.Point(412, 320)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(148, 40)
        Me.BtnDelete.TabIndex = 5
        Me.BtnDelete.Text = "Delete Timetable"
        Me.BtnDelete.UseVisualStyleBackColor = False
        '
        'BtnLabs
        '
        Me.BtnLabs.BackColor = System.Drawing.Color.Honeydew
        Me.BtnLabs.BackgroundImage = CType(resources.GetObject("BtnLabs.BackgroundImage"), System.Drawing.Image)
        Me.BtnLabs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnLabs.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnLabs.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLabs.ForeColor = System.Drawing.Color.DarkGreen
        Me.BtnLabs.Location = New System.Drawing.Point(503, 127)
        Me.BtnLabs.Name = "BtnLabs"
        Me.BtnLabs.Size = New System.Drawing.Size(148, 40)
        Me.BtnLabs.TabIndex = 6
        Me.BtnLabs.Text = "Manage Labs"
        Me.BtnLabs.UseVisualStyleBackColor = False
        '
        'LblLogout
        '
        Me.LblLogout.ActiveLinkColor = System.Drawing.Color.OliveDrab
        Me.LblLogout.AutoSize = True
        Me.LblLogout.BackColor = System.Drawing.Color.Transparent
        Me.LblLogout.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblLogout.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogout.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LblLogout.LinkColor = System.Drawing.Color.DarkGreen
        Me.LblLogout.Location = New System.Drawing.Point(695, 12)
        Me.LblLogout.Name = "LblLogout"
        Me.LblLogout.Size = New System.Drawing.Size(79, 20)
        Me.LblLogout.TabIndex = 8
        Me.LblLogout.TabStop = True
        Me.LblLogout.Text = "LOGOUT"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.LblViewTimetable)
        Me.Panel2.Controls.Add(Me.LblLogout)
        Me.Panel2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 49)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(777, 43)
        Me.Panel2.TabIndex = 10
        '
        'LblViewTimetable
        '
        Me.LblViewTimetable.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LblViewTimetable.AutoSize = True
        Me.LblViewTimetable.BackColor = System.Drawing.Color.Transparent
        Me.LblViewTimetable.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblViewTimetable.ForeColor = System.Drawing.Color.Black
        Me.LblViewTimetable.Location = New System.Drawing.Point(330, 8)
        Me.LblViewTimetable.Name = "LblViewTimetable"
        Me.LblViewTimetable.Size = New System.Drawing.Size(72, 24)
        Me.LblViewTimetable.TabIndex = 0
        Me.LblViewTimetable.Text = "HOME"
        Me.LblViewTimetable.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Ivory
        Me.Label1.Image = CType(resources.GetObject("Label1.Image"), System.Drawing.Image)
        Me.Label1.Location = New System.Drawing.Point(186, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(431, 33)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Computer Science Course Scheduler"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(777, 49)
        Me.Panel1.TabIndex = 9
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(370, 92)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(407, 391)
        Me.PictureBox2.TabIndex = 11
        Me.PictureBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label2.Location = New System.Drawing.Point(181, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(214, 68)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Please select a time to begin..."
        '
        'LblAdmin
        '
        Me.LblAdmin.AutoSize = True
        Me.LblAdmin.BackColor = System.Drawing.Color.Transparent
        Me.LblAdmin.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAdmin.ForeColor = System.Drawing.Color.DarkGreen
        Me.LblAdmin.Location = New System.Drawing.Point(186, 137)
        Me.LblAdmin.Name = "LblAdmin"
        Me.LblAdmin.Size = New System.Drawing.Size(57, 22)
        Me.LblAdmin.TabIndex = 13
        Me.LblAdmin.Text = "Label3"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(777, 484)
        Me.Controls.Add(Me.LblAdmin)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BtnLabs)
        Me.Controls.Add(Me.BtnDelete)
        Me.Controls.Add(Me.BtnUpdate)
        Me.Controls.Add(Me.BtnView)
        Me.Controls.Add(Me.BtnCreate)
        Me.Controls.Add(Me.BtnLecturers)
        Me.Controls.Add(Me.PictureBox2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Main"
        Me.ShowIcon = False
        Me.Text = "Main"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnLecturers As Button
    Friend WithEvents BtnCreate As Button
    Friend WithEvents BtnView As Button
    Friend WithEvents BtnUpdate As Button
    Friend WithEvents BtnDelete As Button
    Friend WithEvents BtnLabs As Button
    Friend WithEvents LblLogout As LinkLabel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents LblViewTimetable As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents LblAdmin As Label
End Class
